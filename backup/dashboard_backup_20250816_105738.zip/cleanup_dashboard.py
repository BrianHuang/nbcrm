#!/usr/bin/env python3
"""
NBCRM Dashboard 清理腳本
自動移除 Dashboard 相關檔案和代碼，轉換為純 Django Admin 架構

使用方式:
python cleanup_dashboard.py --dry-run  # 預覽將要刪除的檔案
python cleanup_dashboard.py --execute  # 實際執行清理
python cleanup_dashboard.py --backup   # 先備份再清理
"""

import os
import sys
import shutil
import re
import argparse
import json
from datetime import datetime
from pathlib import Path
import zipfile

class NBCRMCleanup:
    def __init__(self, project_root=None):
        self.project_root = Path(project_root) if project_root else Path.cwd()
        self.backup_dir = self.project_root / 'backup' / f'dashboard_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
        self.removed_files = []
        self.modified_files = []
        
        # 定義要清理的目錄和檔案模式
        self.cleanup_patterns = {
            'directories': [
                'static/dashboard/',
                'static/js/dashboard/',
                'static/css/dashboard/',
                'templates/dashboard/',
                'static/admin-dashboard/',
                'media/dashboard/',
            ],
            'files': [
                'static/js/dashboard*.js',
                'static/css/dashboard*.css',
                'templates/*dashboard*.html',
                '*/views/dashboard*.py',
                '*/dashboard_views.py',
                '*/dashboard_urls.py',
            ],
            'patterns_in_files': [
                r'dashboard',
                r'Dashboard',
                r'DASHBOARD',
            ]
        }
        
        # 需要修改的檔案類型
        self.files_to_modify = [
            'urls.py',
            'settings.py',
            'views.py',
            '*/urls.py',
            '*/views.py',
            'requirements.txt',
        ]

    def create_backup(self):
        """創建備份"""
        print(f"🔄 正在創建備份到: {self.backup_dir}")
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # 創建完整專案備份的 ZIP 檔案
        backup_zip = self.backup_dir.parent / f"{self.backup_dir.name}.zip"
        
        with zipfile.ZipFile(backup_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(self.project_root):
                # 跳過已經存在的備份目錄
                if 'backup' in Path(root).parts:
                    continue
                    
                for file in files:
                    file_path = Path(root) / file
                    # 跳過 .git, __pycache__, .pyc 等檔案
                    if any(skip in str(file_path) for skip in ['.git', '__pycache__', '.pyc', 'node_modules']):
                        continue
                        
                    arcname = file_path.relative_to(self.project_root)
                    zipf.write(file_path, arcname)
        
        print(f"✅ 備份完成: {backup_zip}")
        return backup_zip

    def find_files_to_remove(self):
        """找出需要移除的檔案和目錄"""
        files_to_remove = []
        
        # 檢查目錄
        for dir_pattern in self.cleanup_patterns['directories']:
            dir_path = self.project_root / dir_pattern
            if dir_path.exists():
                files_to_remove.append(('directory', dir_path))
        
        # 檢查檔案模式
        for file_pattern in self.cleanup_patterns['files']:
            for file_path in self.project_root.rglob(file_pattern):
                if file_path.exists() and file_path.is_file():
                    files_to_remove.append(('file', file_path))
        
        return files_to_remove

    def find_dashboard_references(self):
        """找出包含 dashboard 引用的檔案"""
        references = []
        
        for file_path in self.project_root.rglob("*.py"):
            if any(skip in str(file_path) for skip in ['__pycache__', '.git', 'backup', 'venv', 'env']):
                continue
                
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                for line_num, line in enumerate(content.split('\n'), 1):
                    for pattern in self.cleanup_patterns['patterns_in_files']:
                        if re.search(pattern, line, re.IGNORECASE):
                            references.append({
                                'file': file_path,
                                'line': line_num,
                                'content': line.strip(),
                                'pattern': pattern
                            })
            except (UnicodeDecodeError, PermissionError):
                continue
                
        return references

    def clean_urls_py(self, file_path):
        """清理 urls.py 中的 dashboard 相關路由"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # 移除 dashboard 相關的 URL 模式
            patterns_to_remove = [
                r"path\(['\"]dashboard[^,]*,.*?\),?\s*\n",
                r"path\(['\"][^'\"]*dashboard[^,]*,.*?\),?\s*\n",
                r"url\([^,]*dashboard[^,]*,.*?\),?\s*\n",
                r"include\(['\"][^'\"]*dashboard[^'\"]*['\"].*?\),?\s*\n",
            ]
            
            for pattern in patterns_to_remove:
                content = re.sub(pattern, '', content, flags=re.MULTILINE | re.IGNORECASE)
            
            # 移除 dashboard views 的 import
            import_patterns = [
                r"from\s+[.\w]*dashboard[.\w]*\s+import.*\n",
                r"import\s+[.\w]*dashboard[.\w]*.*\n",
            ]
            
            for pattern in import_patterns:
                content = re.sub(pattern, '', content, flags=re.MULTILINE | re.IGNORECASE)
            
            if content != original_content:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                return True
                
        except Exception as e:
            print(f"⚠️  警告: 無法處理 {file_path}: {e}")
            
        return False

    def clean_settings_py(self, file_path):
        """清理 settings.py 中的 dashboard 相關設定"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # 移除 INSTALLED_APPS 中的 dashboard 應用
            content = re.sub(
                r"['\"][\w.]*dashboard[\w.]*['\"],?\s*\n",
                '',
                content,
                flags=re.IGNORECASE
            )
            
            # 移除 dashboard 相關的設定
            dashboard_settings = [
                'DASHBOARD_',
                'dashboard_',
            ]
            
            for setting in dashboard_settings:
                pattern = rf"^{setting}[A-Z_]*\s*=.*$"
                content = re.sub(pattern, '', content, flags=re.MULTILINE | re.IGNORECASE)
            
            if content != original_content:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                return True
                
        except Exception as e:
            print(f"⚠️  警告: 無法處理 {file_path}: {e}")
            
        return False

    def clean_requirements_txt(self, file_path):
        """清理 requirements.txt 中的 dashboard 相關套件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            original_lines = lines.copy()
            
            # 移除包含 dashboard 的套件
            lines = [line for line in lines if not re.search(r'dashboard', line, re.IGNORECASE)]
            
            if lines != original_lines:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                return True
                
        except Exception as e:
            print(f"⚠️  警告: 無法處理 {file_path}: {e}")
            
        return False

    def execute_cleanup(self, dry_run=False):
        """執行清理操作"""
        
        if not dry_run:
            print("🚀 開始執行 NBCRM Dashboard 清理...")
        else:
            print("👀 預覽模式 - 以下是將要執行的操作:")
        
        # 1. 找出要移除的檔案
        files_to_remove = self.find_files_to_remove()
        
        if files_to_remove:
            print(f"\n📁 將移除 {len(files_to_remove)} 個檔案/目錄:")
            for file_type, file_path in files_to_remove:
                rel_path = file_path.relative_to(self.project_root)
                print(f"  🗑️  {file_type}: {rel_path}")
                
                if not dry_run:
                    try:
                        if file_type == 'directory':
                            shutil.rmtree(file_path)
                        else:
                            file_path.unlink()
                        self.removed_files.append(str(rel_path))
                    except Exception as e:
                        print(f"    ❌ 刪除失敗: {e}")
        
        # 2. 清理程式碼中的引用
        print(f"\n📝 清理程式碼引用:")
        
        # 處理 urls.py
        for urls_file in self.project_root.rglob("urls.py"):
            if any(skip in str(urls_file) for skip in ['backup', 'venv', 'env']):
                continue
                
            rel_path = urls_file.relative_to(self.project_root)
            print(f"  🔧 處理: {rel_path}")
            
            if not dry_run:
                if self.clean_urls_py(urls_file):
                    self.modified_files.append(str(rel_path))
        
        # 處理 settings.py
        for settings_file in self.project_root.rglob("settings.py"):
            if any(skip in str(settings_file) for skip in ['backup', 'venv', 'env']):
                continue
                
            rel_path = settings_file.relative_to(self.project_root)
            print(f"  🔧 處理: {rel_path}")
            
            if not dry_run:
                if self.clean_settings_py(settings_file):
                    self.modified_files.append(str(rel_path))
        
        # 處理 requirements.txt
        requirements_file = self.project_root / "requirements.txt"
        if requirements_file.exists():
            rel_path = requirements_file.relative_to(self.project_root)
            print(f"  🔧 處理: {rel_path}")
            
            if not dry_run:
                if self.clean_requirements_txt(requirements_file):
                    self.modified_files.append(str(rel_path))
        
        # 3. 顯示需要手動檢查的引用
        references = self.find_dashboard_references()
        if references:
            print(f"\n⚠️  發現 {len(references)} 個可能需要手動檢查的引用:")
            
            # 按檔案分組顯示
            files_with_refs = {}
            for ref in references:
                file_key = str(ref['file'].relative_to(self.project_root))
                if file_key not in files_with_refs:
                    files_with_refs[file_key] = []
                files_with_refs[file_key].append(ref)
            
            for file_path, refs in files_with_refs.items():
                print(f"  📄 {file_path}:")
                for ref in refs[:3]:  # 只顯示前3個引用
                    print(f"    📍 第 {ref['line']} 行: {ref['content'][:60]}...")
                if len(refs) > 3:
                    print(f"    ... 還有 {len(refs) - 3} 個引用")
        
        # 4. 生成報告
        if not dry_run:
            self.generate_report()
        
        print(f"\n{'🎯 預覽完成!' if dry_run else '✅ 清理完成!'}")

    def generate_report(self):
        """生成清理報告"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'removed_files': self.removed_files,
            'modified_files': self.modified_files,
            'backup_location': str(self.backup_dir) if self.backup_dir.exists() else None,
        }
        
        report_file = self.project_root / 'cleanup_report.json'
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"📊 清理報告已保存: {report_file}")

    def create_admin_only_urls(self):
        """創建簡化的 urls.py 檔案"""
        admin_urls_content = '''"""
NBCRM URL Configuration - Admin Only
移除 Dashboard 後的簡化版本
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

# 自定義 Admin 網站資訊
admin.site.site_header = 'NBCRM 管理系統'
admin.site.site_title = 'NBCRM'
admin.site.index_title = '歡迎使用 NBCRM 管理系統'

urlpatterns = [
    path('admin/', admin.site.urls),
    # 如果需要 API 端點，取消註解下面這行
    # path('api/', include('api.urls')),
]

# 開發環境下的媒體檔案服務
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
'''
        
        urls_file = self.project_root / 'urls.py'
        
        # 備份原始檔案
        if urls_file.exists():
            backup_file = urls_file.with_suffix('.py.backup')
            shutil.copy2(urls_file, backup_file)
            print(f"📋 原始 urls.py 已備份為: {backup_file}")
        
        # 寫入新的 urls.py
        with open(urls_file, 'w', encoding='utf-8') as f:
            f.write(admin_urls_content)
        
        print(f"✅ 已創建簡化的 urls.py")


def main():
    parser = argparse.ArgumentParser(description='NBCRM Dashboard 清理腳本')
    parser.add_argument('--dry-run', action='store_true', 
                       help='預覽模式，不實際刪除檔案')
    parser.add_argument('--execute', action='store_true', 
                       help='執行清理操作')
    parser.add_argument('--backup', action='store_true', 
                       help='先備份再清理')
    parser.add_argument('--project-root', type=str, 
                       help='專案根目錄路徑（預設為當前目錄）')
    parser.add_argument('--create-urls', action='store_true',
                       help='創建簡化的 urls.py 檔案')
    
    args = parser.parse_args()
    
    if not any([args.dry_run, args.execute, args.backup, args.create_urls]):
        parser.print_help()
        print("\n請選擇一個操作模式!")
        sys.exit(1)
    
    # 確認專案目錄
    project_root = Path(args.project_root) if args.project_root else Path.cwd()
    if not project_root.exists():
        print(f"❌ 專案目錄不存在: {project_root}")
        sys.exit(1)
    
    # 檢查是否為 Django 專案
    if not (project_root / 'manage.py').exists():
        print(f"⚠️  警告: {project_root} 似乎不是 Django 專案目錄")
        response = input("是否繼續? (y/N): ")
        if response.lower() != 'y':
            sys.exit(1)
    
    cleanup = NBCRMCleanup(project_root)
    
    try:
        if args.backup or (args.execute and not args.dry_run):
            # 先創建備份
            cleanup.create_backup()
        
        if args.create_urls:
            cleanup.create_admin_only_urls()
        
        if args.dry_run:
            cleanup.execute_cleanup(dry_run=True)
        elif args.execute or args.backup:
            cleanup.execute_cleanup(dry_run=False)
        
    except KeyboardInterrupt:
        print("\n\n❌ 操作已取消")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 執行過程中出現錯誤: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()